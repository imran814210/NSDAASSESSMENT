
function timeFun(){
const d = new Date();			
		function addZero(i) {
				  if (i < 10) {i = "0" + i}
				  return i;
				}
				const h = addZero(d.getHours());
				const minutes = addZero(d.getMinutes());
				const s = addZero(d.getSeconds());
				const m=addZero(d.getMonth()+1);
				const dt=addZero(d.getDate());				
				const time = h + ":" + m + ":" + s;
		const day = "Date "+dt+"-"+m+"-"+d.getFullYear()+" Time "+time;
		                 document.getElementById("ntime").innerHTML = day;
}

var acc = document.getElementsByClassName("question");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var ans = this.nextElementSibling;
    if (ans.style.display === "block") {
      ans.style.display = "none";
    } else {
      ans.style.display = "block";
    }
  });
}